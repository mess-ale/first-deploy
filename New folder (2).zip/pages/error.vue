<template>
    <div class="error-page">
      <h1>404 - Page Not Found</h1>
      <p>Sorry, the page you're looking for doesn't exist.</p>
      <NuxtLink to="/">Go back to homepage</NuxtLink>
    </div>
  </template>
  
  <style scoped>
  .error-page {
    text-align: center;
    padding: 50px;
  }
  </style>