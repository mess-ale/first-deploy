<template>
    <div class="text-primary pb-8">
        <ServiceCard text="Loan" imgservice="/service/loan-p.png" />
        <div class="body-padding_margin">
            <div class="container">
                <div class="duration-500 flex gap-4">
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-10">
                        <div>
                            <div class="saving-right-box p-4">
                                <h1 class="text-primary font-oswald text-2xl text-center font-bold p-4">Lone types</h1>
                                <div class="space-y-2">
                                    <div class="gap-4 p-4 border-b border-gray-200">
                                        <div class="flex items-center text-secondary space-x-4">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="2em" height="2em"
                                                viewBox="0 0 32 32">
                                                <path fill="currentColor"
                                                    d="m15 22l-1.41 1.41L16.17 26H4V8H2v18c0 1.103.897 2 2 2h12.17l-2.58 2.59L15 32l5-5z">
                                                </path>
                                                <circle cx="11" cy="16" r="1" fill="currentColor"></circle>
                                                <path fill="currentColor"
                                                    d="M24 20H8c-1.103 0-2-.897-2-2v-4c0-1.103.897-2 2-2h16c1.103 0 2 .897 2 2v4c0 1.103-.897 2-2 2M8 14v4h16v-4z">
                                                </path>
                                                <path fill="currentColor"
                                                    d="M28 4H15.83l2.58-2.59L17 0l-5 5l5 5l1.41-1.41L15.83 6H28v18h2V6c0-1.102-.897-2-2-2">
                                                </path>
                                            </svg>

                                            <h2 class="text-2xl flex items-center font-bold">Personal Loans</h2>
                                        </div>
                                        <p class="text-primary items-center flex text-justify">
                                            We offer flexible personal loans with competitive rates to help you manage
                                            life’s
                                            expenses, from home improvements to medical emergencies. </p>
                                    </div>

                                    <div class="gap-4 p-4 border-b border-gray-200">
                                        <div class="flex items-center text-secondary space-x-4">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="2em" height="2em"
                                                viewBox="0 0 512 512">
                                                <path fill="currentColor"
                                                    d="M432 176H320V64a48 48 0 0 0-48-48H80a48 48 0 0 0-48 48v416a16 16 0 0 0 16 16h104a8 8 0 0 0 8-8v-71.55c0-8.61 6.62-16 15.23-16.43A16 16 0 0 1 192 416v72a8 8 0 0 0 8 8h264a16 16 0 0 0 16-16V224a48 48 0 0 0-48-48M98.08 431.87a16 16 0 1 1 13.79-13.79a16 16 0 0 1-13.79 13.79m0-80a16 16 0 1 1 13.79-13.79a16 16 0 0 1-13.79 13.79m0-80a16 16 0 1 1 13.79-13.79a16 16 0 0 1-13.79 13.79m0-80a16 16 0 1 1 13.79-13.79a16 16 0 0 1-13.79 13.79m0-80a16 16 0 1 1 13.79-13.79a16 16 0 0 1-13.79 13.79m80 240a16 16 0 1 1 13.79-13.79a16 16 0 0 1-13.79 13.79m0-80a16 16 0 1 1 13.79-13.79a16 16 0 0 1-13.79 13.79m0-80a16 16 0 1 1 13.79-13.79a16 16 0 0 1-13.79 13.79m0-80a16 16 0 1 1 13.79-13.79a16 16 0 0 1-13.79 13.79m80 320a16 16 0 1 1 13.79-13.79a16 16 0 0 1-13.79 13.79m0-80a16 16 0 1 1 13.79-13.79a16 16 0 0 1-13.79 13.79m0-80a16 16 0 1 1 13.79-13.79a16 16 0 0 1-13.79 13.79m0-80a16 16 0 1 1 13.79-13.79a16 16 0 0 1-13.79 13.79m0-80a16 16 0 1 1 13.79-13.79a16 16 0 0 1-13.79 13.79M444 464H320V208h112a16 16 0 0 1 16 16v236a4 4 0 0 1-4 4">
                                                </path>
                                                <path fill="currentColor"
                                                    d="M400 400a16 16 0 1 0 16 16a16 16 0 0 0-16-16m0-80a16 16 0 1 0 16 16a16 16 0 0 0-16-16m0-80a16 16 0 1 0 16 16a16 16 0 0 0-16-16m-64 160a16 16 0 1 0 16 16a16 16 0 0 0-16-16m0-80a16 16 0 1 0 16 16a16 16 0 0 0-16-16m0-80a16 16 0 1 0 16 16a16 16 0 0 0-16-16">
                                                </path>
                                            </svg>

                                            <h2 class="text-lg font-bold">Business Loans</h2>
                                        </div>
                                        <p class="text-primary text-justify">
                                            Empower your business with fast and affordable financing options. Our
                                            business loans
                                            are
                                            designed to fuel your growth and keep your operations running smoothly. </p>
                                    </div>

                                    <div class="gap-4 p-4 border-b border-gray-200">
                                        <div class="flex items-center text-secondary space-x-4">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="2em" height="2em"
                                                viewBox="0 0 24 24">
                                                <path fill="currentColor"
                                                    d="M5 19v-5h6v5v-5H5zm-4 2V11l7-5l7 5l-.712.713l-.713.712L8 8.45L3 12v7h2v-5h6v7H9v-5H7v5zM23 3v10.125q-.425-.45-.925-.812T21 11.675V5h-9v1.4l-2-1.45V3zm-6 6h2V7h-2zm1 14q-2.075 0-3.537-1.463T13 18t1.463-3.537T18 13t3.538 1.463T23 18t-1.463 3.538T18 23m-.5-2h1v-2.5H21v-1h-2.5V15h-1v2.5H15v1h2.5z">
                                                </path>
                                            </svg>

                                            <h2 class="text-lg font-bold">Home Loans</h2>
                                        </div>
                                        <p class="text-primary text-justify">
                                            Make your dream home a reality. Explore our low-interest home loan options
                                            with
                                            manageable payment plans. </p>
                                    </div>

                                    <div class="gap-4 p-4">
                                        <div class="flex items-center text-secondary space-x-4">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="2em" height="2em"
                                                viewBox="0 0 20 20">
                                                <path fill="currentColor"
                                                    d="M3.33 8L10 12l10-6l-10-6L0 6h10v2zM0 8v8l2-2.22V9.2zm10 12l-5-3l-2-1.2v-6l7 4.2l7-4.2v6z">
                                                </path>
                                            </svg>
                                            <h2 class="text-lg font-bold">Educational Loans</h2>
                                        </div>
                                        <p class="text-primary text-justify">
                                            Invest in your future with our education loans. Whether it’s for college or
                                            vocational
                                            training, we’ve got you covered. </p>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div>
                            <ul class="list-disc pl-5">
                                <h1 class="saving-title">Types of Eticare Loans,</h1>
                                <li>Consumer loan</li>
                                <li>Loans for education</li>
                                <li>Medical loan</li>
                                <li>Furniture accessories</li>
                                <li>Social service (wedding, birthday, graduation...)</li>
                                <li>Travel loan to visit different places</li>
                            </ul>

                            <ul class="list-disc pl-5">
                                <h1 class="saving-title">Business loans.</h1>
                                <li>Loans for urban agriculture;
                                    Small business loans;
                                    Loans for service work;
                                    Loans for manufacturing;
                                    Construction loan;
                                    Loans for home purchase, construction and renovation
                                    Housing</li>
                                <li>Business house
                                    Completion of condominium construction
                                    Car loan
                                    Home car
                                    Commercial vehicle
                                    Taxi service car
                                    Public transport car
                                    Special short-term loan
                                    Lease finance loan
                                    Interest free loan services
                                    Salary loan</li>
                            </ul>

                            <h1 class="saving-title">Loan amount and repayment period </h1>

                            <ul class="list-disc pl-5">
                                <h1 class="saving-title">Consumer loan</h1>
                                <li>5/Five months/ and above 15% regular savings and 10% lottery Own member gets a
                                    consumer
                                    loan,
                                    the loan limit is 300,000.00 and the repayment period is up to It will be up to 30
                                    months.
                                </li>
                                <li>6/six months/ and above 15% regular savings and 10% interest Own member gets a
                                    consumer
                                    loan,
                                    the loan limit is 400,000.00 and the repayment period is up to It will be up to 36
                                    months.
                                </li>
                            </ul>

                            <ul class="list-disc pl-5">
                                <h1 class="saving-title"> Business loan </h1>
                                <li>5/Five months/ and above 20% normal savings and 10% lottery Your member can get a
                                    business
                                    loan
                                    with a loan limit of 500,000.00 and a repayment period of up to It will be up to 36
                                    months.
                                </li>
                                <li>6/six months/more than 20% normal savings and 10% lottery Own member gets a business
                                    loan;
                                    the
                                    loan limit is 750,000.00 and the repayment period is up to It will be up to 48
                                    months.</li>
                                <li>12/twelve months/ more than 20% regular savings and 5% interest Own member gets a
                                    business
                                    loan
                                    and the loan limit is 1,500,000.00 and the repayment period It will be up to 60
                                    months</li>
                            </ul>

                            <ul class="list-disc pl-5">
                                <h1 class="saving-title">Loans for home purchase, construction and renovation </h1>
                                <li>20% normal savings of 6/six months/ and above in a row to borrow a home loan A
                                    member who
                                    saves
                                    and buys a 10% lot gets a home loan with a loan limit of 2,000,000.00. The repayment
                                    period
                                    will
                                    be up to 60 months. </li>
                                <li>8/eight months/ and above 20% regular savings and 10% interest Own member gets a
                                    home loan
                                    and
                                    the loan limit is 3,000,000.00 and the repayment period is up to It will be up to 84
                                    months.
                                </li>
                                <li>12/twelve months/ and above 18% regular savings and 7% A member who owns a lot gets
                                    a home
                                    loan
                                    and the loan ceiling is 5,000,000.00 and the repayment period is It will be up to 84
                                    months.
                                </li>
                            </ul>

                            <ul class="list-disc pl-5">
                                <h1 class="saving-title">Car loan </h1>
                                <li>20% regular savings of 6 months and more and 10% of lotteries A member gets a car
                                    loan with
                                    a
                                    loan limit of 2,000,000.00 and a repayment period will be up to 48 months. </li>
                                <li>8/eight months/ and more who has saved 20% regular savings and bought 5% lottery A
                                    member
                                    gets
                                    a car loan with a loan limit of up to 3,000,000.00 and the repayment period will be
                                    up to 60
                                    months.</li>
                            </ul>

                            <ul class="list-disc pl-5">
                                <h1 class="saving-title">Special short-term loans </h1>
                                <li>For four months and more, he has saved 25% regular savings and bought 5% lotteries
                                    and A
                                    special short-term loan for members in business with no interest at 10% commission
                                    You will
                                    get
                                    it by paying only /Commission/ and the loan limit is 400,000.00 and the repayment
                                    period It
                                    will
                                    last up to four months. The loan repayment period is twice a month every fifteen
                                    days </li>
                                <li>6 months continuous borrowing 20% ​​regular savings and 5% lot purchase and business
                                    Special
                                    short-term loan for working members with no interest paid at 15% commission only.
                                    You will
                                    get
                                    it by paying, and the loan ceiling is 600,000.00 and the repayment period will be up
                                    to 6
                                    months. The loan repayment period will be twice a month every fifteen days</li>
                            </ul>
                            <ul class="list-disc pl-5">
                                <h1 class="saving-title">Salary loan </h1>
                                <li>For member of government employees, bank employees, insurance employees and hospital
                                    employees
                                    15% advance savings and 5% of 6 months net salary for emergency loans Complete the
                                    lot and
                                    submit a letter of guarantee from the office where you are working for a loan that
                                    will be
                                    repaid in one year You can borrow.</li>
                                <li>6 months continuous borrowing 20% ​​regular savings and 5% lot purchase and business
                                    Special
                                    short-term loan for working members with no interest paid at 15% commission only.
                                    You will
                                    get
                                    it by paying, and the loan ceiling is 600,000.00 and the repayment period will be up
                                    to 6
                                    months. The loan repayment period will be twice a month every fifteen days</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script setup>
useHead({
  title: 'Loan - Etcare SACCOs Ltd',
});
</script>