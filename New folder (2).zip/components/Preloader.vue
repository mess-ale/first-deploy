<template>
    <div v-if="loading" class="loading-overlay">
        <div class="spinner"></div>
    </div>
</template>

<script>export default {
    data() {
        return { loading: true };
    },
    mounted() {
        const images = document.querySelectorAll("img");
        let loadedCount = 0;
        const totalImages = images.length;

        if (totalImages === 0) {
            this.loading = false;
        } else {
            const checkLoad = () => {
                loadedCount++;
                console.log(loadedCount)
                if (loadedCount === totalImages) {
                    this.loading = false;
                }
            };

            images.forEach((img) => {
                img.onload = checkLoad;
                img.onerror = checkLoad;
                if (img.complete) {
                    checkLoad();
                }

            });
        }
    },
};</script>

<style>
.loading-overlay {
    position: fixed;
    top: 0;
    left: 0;
    width: 100vw;
    height: 100vh;
    background: #214080;
    display: flex;
    justify-content: center;
    align-items: center;
    z-index: 9999;
}

.spinner {
    width: 50px;
    height: 50px;
    border: 5px solid #ccc;
    border-top: 5px solid #214080;
    border-radius: 50%;
    animation: spin 1s linear infinite;
}

@keyframes spin {
    0% {
        transform: rotate(0deg);
    }

    100% {
        transform: rotate(360deg);
    }
}
</style>